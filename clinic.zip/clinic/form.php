<?php
$firstname = $_post['firstname'];
$age = $_post['age'];
$appointment_date = $_post['appointment_date'];
$appointment_time = $_post['appointment_time'];
$email = $_post['email'];
$contact_number = $_post['contact_number'];

//database connection
$conn = new mysqli('localhost','root','','registration');
if($conn->connection_error){
    die('connection failed :'.$conn->connection_error);
}else{
    $stmt = $conn->prepare("insert into registration(firstname,age,appointment_date,appointment_time,email,contact_number)
    values(?,?,?,?,?,?)");
    $stmt->bind_param("sisssi",$firstname,$age,$appointment_date,$appointment_time,$email,$contact_number);
    $stmt->execute();
    echo"registration successfully....";
    $stmt->close();
    $conn->close();
}
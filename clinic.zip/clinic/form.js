$(document).ready(function() {
    $('#appointmentForm').on('submit', function(event) {
        event.preventDefault();

        $.ajax({
            type: 'POST',
            url: 'form.php',
            data: $(this).serialize(),
            success: function(response) {
                $('#successMessage').html(response);
            },
            error: function(xhr, status, error) {
                $('#successMessage').html('Error: ' + error);
            }
        });
    });
});